# yield-aggregator

A basic template for a yield aggregator vault that can be extended to route funds into external DeFi protocols.

## Features
- Simple vault-style contract stub
- Deposit / withdraw interface
- Hardhat setup

## Tech Stack
- Solidity
- Hardhat
- Node.js
