async function main() {
  const Contract = await ethers.getContractFactory("YieldVault");
  const contract = await Contract.deploy();
  await contract.deployed();
  console.log("YieldVault deployed to:", contract.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
